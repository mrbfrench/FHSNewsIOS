//
//  ViewController.swift
//  FHSNewsIOS
//
//  Created by Brigham French on 1/6/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

